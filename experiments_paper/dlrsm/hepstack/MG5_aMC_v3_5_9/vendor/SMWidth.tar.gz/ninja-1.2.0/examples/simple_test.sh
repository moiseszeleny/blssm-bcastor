#! /bin/sh

ninjanumgen mynum.frm --nlegs 4 --rank 4 -o mynum.cc
