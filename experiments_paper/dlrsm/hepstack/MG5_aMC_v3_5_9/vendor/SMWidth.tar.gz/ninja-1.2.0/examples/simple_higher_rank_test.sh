#! /bin/sh

ninjanumgen mynumhr.frm --nlegs 5 --rank 6 -o mynumhr.cc
