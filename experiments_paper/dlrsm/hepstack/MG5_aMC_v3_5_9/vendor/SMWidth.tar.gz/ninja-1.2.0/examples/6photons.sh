#! /bin/sh

ninjanumgen 6photons.frm --nlegs 6 --rank 6 --diagname SixPhotons \
    -o 6photons_num.cc
